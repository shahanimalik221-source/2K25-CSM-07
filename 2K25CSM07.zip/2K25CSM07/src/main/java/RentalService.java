public class RentalService {
    private static final double DRIVER_CHARGE_PER_DAY = 1500;

    public void showCatalog(Vehicle[] vehicles) {
        System.out.println("\n--- Available Vehicles ---");
        for (int i = 0; i < vehicles.length; i++) {
            System.out.print((i + 1) + ". ");
            vehicles[i].showDetails();
        }
        System.out.println("--------------------------");
    }

    public void rentVehicle(Vehicle vehicle, int days, boolean needDriver) {
        if (vehicle.getStock() <= 0) {
            System.out.println("Sorry, this vehicle is currently out of stock!");
            return;
        }

        double baseCost = vehicle.calculateCost(days);
        double driverCost = needDriver ? (DRIVER_CHARGE_PER_DAY * days) : 0;
        double totalCost = baseCost + driverCost;

        System.out.println("\n========== RENTAL RECEIPT ==========");
        System.out.println("Vehicle: " + vehicle.getBrand() + " " + vehicle.getModel());
        System.out.println("Fuel Type: " + vehicle.getFuelType());
        System.out.println("Rental Days: " + days);
        System.out.println("Base Cost: Rs " + baseCost);
        if (needDriver) {
            System.out.println("Driver Charge: Rs " + driverCost + " (Rs " + DRIVER_CHARGE_PER_DAY + "/day)");
        }
        System.out.println("------------------------------------");
        System.out.println("TOTAL AMOUNT: Rs " + totalCost);
        System.out.println("====================================");

        vehicle.reduceStock();
        System.out.println("Thank you! Your rental has been confirmed.");
    }
}
