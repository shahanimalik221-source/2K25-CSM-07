public class Vehicle {
    private String brand;
    private String model;
    private double pricePerDay;
    private int stock;
    private String fuelType;

    public Vehicle(String brand, String model, double pricePerDay, int stock, String fuelType) {
        this.brand = brand;
        this.model = model;
        this.pricePerDay = pricePerDay;
        this.stock = stock;
        this.fuelType = fuelType;
    }

    public String getBrand() { return brand; }
    public String getModel() { return model; }
    public double getPricePerDay() { return pricePerDay; }
    public int getStock() { return stock; }
    public String getFuelType() { return fuelType; }

    public void reduceStock() {
        if (stock > 0) stock--;
    }

    public void showDetails() {
        System.out.println(brand + " " + model + " | Fuel: " + fuelType +
                " | Rs " + pricePerDay + "/day | Stock: " + stock);
    }

    public double calculateCost(int days) {
        return pricePerDay * days;
    }
}
