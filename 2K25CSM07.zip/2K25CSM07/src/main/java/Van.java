public class Van extends Vehicle {
    private int seatingCapacity;

    public Van(String brand, String model, double pricePerDay, int stock, String fuelType, int seatingCapacity) {
        super(brand, model, pricePerDay, stock, fuelType);
        this.seatingCapacity = seatingCapacity;
    }

    @Override
    public void showDetails() {
        System.out.println("[VAN] " + getBrand() + " " + getModel() +
                " | Seats: " + seatingCapacity +
                " | Fuel: " + getFuelType() +
                " | Rs " + getPricePerDay() + "/day | Stock: " + getStock());
    }

    @Override
    public double calculateCost(int days) {
        double base = super.calculateCost(days);
        return base + seatingCapacity * 40;  // slight seating charge
    }
}
