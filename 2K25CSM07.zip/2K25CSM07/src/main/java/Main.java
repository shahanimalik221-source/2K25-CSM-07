import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Vehicle v1 = new Car("Toyota", "Corolla 2017", 4500, 5, "Petrol", false);
        Vehicle v2 = new Car("Suzuki", "Alto VXR", 3000, 6, "Petrol", false);
        Vehicle v3 = new Car("Honda", "Civic 2020", 6500, 3, "Petrol", true);
        Vehicle v4 = new Van("Toyota", "Hiace Van", 8000, 4, "Diesel", 14);
        Vehicle v5 = new Car("Toyota", "Yaris 2021", 5000, 5, "Petrol", false);
        Vehicle v6 = new Car("Suzuki", "WagonR 2022", 3500, 7, "Petrol", false);

        Vehicle[] catalog = { v1, v2, v3, v4, v5, v6 };

        RentalService service = new RentalService();
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n=========== WELCOME TO PAKISTANI RENT A CAR ===========");
            System.out.println("1. View Vehicles");
            System.out.println("2. Rent a Vehicle");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            int ch = sc.nextInt();

            switch (ch) {
                case 1:
                    service.showCatalog(catalog);
                    break;

                case 2:
                    service.showCatalog(catalog);
                    System.out.print("Enter vehicle number (1–6): ");
                    int v = sc.nextInt();

                    if (v < 1 || v > 6) {
                        System.out.println("Invalid choice!");
                        break;
                    }

                    System.out.print("Enter number of days: ");
                    int days = sc.nextInt();

                    System.out.print("Need driver? (1 = Yes, 0 = No): ");
                    boolean driver = sc.nextInt() == 1;

                    service.rentVehicle(catalog[v - 1], days, driver);
                    break;

                case 3:
                    System.out.println("Thank you for choosing Pakistani Rent A Car!");
                    sc.close();
                    return;

                default:
                    System.out.println("Invalid choice!");
            }
        }
    }
}
