public class Car extends Vehicle {
    private boolean luxury;

    public Car(String brand, String model, double pricePerDay, int stock, String fuelType, boolean luxury) {
        super(brand, model, pricePerDay, stock, fuelType);
        this.luxury = luxury;
    }

    @Override
    public void showDetails() {
        System.out.println("[CAR] " + getBrand() + " " + getModel() +
                " | Fuel: " + getFuelType() +
                " | Rs " + getPricePerDay() + "/day | Stock: " + getStock() +
                " | Luxury: " + (luxury ? "Yes" : "No"));
    }

    @Override
    public double calculateCost(int days) {
        double cost = super.calculateCost(days);
        if (luxury) cost += 3000;  // luxury fee
        return cost;
    }
}
